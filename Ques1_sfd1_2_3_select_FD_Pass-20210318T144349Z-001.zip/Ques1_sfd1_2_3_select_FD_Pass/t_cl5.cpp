#include<iostream>
#include <unistd.h>
#include <netdb.h> 
#include <netinet/in.h> 
#include <arpa/inet.h>
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#define MAX 80 
#define PORT 13000
#define SA struct sockaddr 

using namespace std;

void func(int nsfd) { 
	while(1) { 
        char buff[MAX]; 
		cout<<"Enter the string : "; 
        string str1;
        getline(cin,str1);
		send(nsfd, str1.c_str(), str1.length(),0); 
		int br=recv(nsfd, buff, 100,0);
        buff[br]=0; 
		cout<< buff<<"\n"; 
		if(str1=="exit"){
            break;
        } 
	} 
} 

int main() { 
	int sfd, connfd; 
	struct sockaddr_in servaddr, cli; 

	sfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sfd == -1) { 
		cout<<"socket creation failed...\n"; 
		exit(0); 
	} 
	else
		cout<<"Socket successfully created..\n"; 
	bzero(&servaddr, sizeof(servaddr)); 

	// assign IP, PORT 
	servaddr.sin_family = AF_INET; 
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1"); 
	servaddr.sin_port = htons(PORT); 

	// connect the client socket to server socket 
	if (connect(sfd, (SA*)&servaddr, sizeof(servaddr)) != 0) { 
		cout<<"connection with the server failed...\n"; 
		exit(0); 
	} 
	else
		cout<<"connected to the server..\n"; 

	func(sfd); 
	close(sfd); 
} 
