#include<iostream>
#include<bits/stdc++.h>
#include <arpa/inet.h> 
#include <netinet/in.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <strings.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include <unistd.h>

#define PORT 12000
#define SA struct sockaddr

using namespace std;
int main() { 
    int usfd; 
    char buf[100]; 
    socklen_t len;
    //  char* buf = "Hello Server"; 
    struct sockaddr_in serv_addr; 
  
    // Creating socket file descriptor 
    if ((usfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) { 
        printf("socket creation failed"); 
        exit(0); 
    } 
  
    memset(&serv_addr, 0, sizeof(serv_addr)); 
  
    // Filling server information 
    serv_addr.sin_family = AF_INET; 
    serv_addr.sin_port = htons(PORT); 
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1"); 
    len =sizeof(serv_addr);
    while(1){
        cout<<"enter the string to get capitalized:-"<<"\n";
        cin>>buf;
        sendto(usfd, (const char*)buf, strlen(buf), 0, (const struct sockaddr*)&serv_addr,len); 
        // receive server's response 
        char buf1[100];
        int br= recvfrom(usfd, (char*)buf1, 100, 0, (struct sockaddr*)&serv_addr, &len); 
        buf1[br]=0;
        cout<<"Message from server: "<<buf1<<"\n";
    }
    close(usfd); 
    return 0; 
} 