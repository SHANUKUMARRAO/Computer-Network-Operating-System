#include "hdr.h"


ssize_t read_fd(int fd, void *ptr, size_t nbytes, int *recvfd){
	struct msghdr	msg;
	struct iovec	iov[1];
	ssize_t			n;
	union {
	  struct cmsghdr	cm;
	  char				control[CMSG_SPACE(sizeof(int))];
	} control_un;
	struct cmsghdr	*cmptr;

	msg.msg_control = control_un.control;
	msg.msg_controllen = sizeof(control_un.control);
	msg.msg_name = NULL;
	msg.msg_namelen = 0;

	iov[0].iov_base = ptr;
	iov[0].iov_len = nbytes;
	msg.msg_iov = iov;
	msg.msg_iovlen = 1;

	if ( (n = recvmsg(fd, &msg, 0)) <= 0)
		return(n);
	if ( (cmptr = CMSG_FIRSTHDR(&msg)) != NULL &&
	    cmptr->cmsg_len == CMSG_LEN(sizeof(int))) {
		if (cmptr->cmsg_level != SOL_SOCKET){
			perror("control level != SOL_SOCKET");
			exit(0);
		}
		if (cmptr->cmsg_type != SCM_RIGHTS){
			perror("control type != SCM_RIGHTS");
			exit(0);
		}
		*recvfd = *((int *) CMSG_DATA(cmptr));
	} else
		*recvfd = -1;		/* descriptor was not passed */
	return(n);
}
int main(int argc, char **argv){
	int	listenfd, connfd,sockfd=-1, n=3, pid =0,nsfd;
    int sfd[n];
    for(int i=0;i<n;i++)
        sfd[i]=-1;

	char buff[MAXLINE];
	pid_t	childpid;
	socklen_t	clilen;
	struct sockaddr_un	cliaddr, servaddr;
	struct sockaddr_in ca;
	
	listenfd = socket(AF_LOCAL, SOCK_STREAM, 0);

	unlink(UNIXSTR_PATH);
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sun_family = AF_LOCAL;
	strcpy(servaddr.sun_path, UNIXSTR_PATH);

	bind(listenfd, (SA *) &servaddr, sizeof(servaddr));

	listen(listenfd, LISTENQ);
    

	clilen = sizeof(cliaddr);
    // cout<<"hello1\n";
	if ( (connfd = accept(listenfd, (SA *) &cliaddr, &clilen)) < 0) {
		if (errno == EINTR)
			exit(0);
		else
		 perror("accept error");
	}
    else cout<<"Accepted\n";
    // cout<<"hello2\n";
    for(int i=0;i<n;i++)
        read_fd(connfd, buff, 1,&sfd[i] );
    // cout<<"hello3\n";

    fd_set read_fds;
    int mx_fd=-1;
    FD_ZERO(&read_fds);
    for(int i=0;i<n;i++){
        if(sfd[i]>mx_fd)mx_fd=sfd[i];
    }
    mx_fd+=1;
    socklen_t len[n];
    // cout<<"hello4\n";
    while(1) {//cout<<"hello5\n";
        for(int i=0;i<n;i++){
            FD_SET(sfd[i],&read_fds);
        }
        int no_of_ready_sfds=select(mx_fd, &read_fds, NULL, NULL, NULL);
        if (no_of_ready_sfds > 0){
            for (int i = 0; i < n; ++i){
                if(i!=1){
                    if (FD_ISSET(sfd[i],&read_fds)){
                        len[i] = sizeof(cliaddr);

                        pid=fork();
                        if(pid>0){
                            // close(sfd[i]);
                        }
                        else{
                            while(1){
                                int br;
                                char buff1[1024];
                                while((br=read(sfd[i], buff1, MAXLINE))>0) {
                                    buff1[br]='\0';
                                    cout<<"Message from client"<<i+3<<":"<<buff1<<"\n";
                                    write(sfd[i], buff1, br);
                                    if(!strcmp(buff, "exit")) 
                                        break;
                                }
                            }
                        }
                    }
                } 
                else if(i==1){
                    if(FD_ISSET(sfd[i],&read_fds)){
                        len[i]=sizeof(cliaddr);
                        while(1){
                            char buf[100];
                            int br=recvfrom(sfd[i],buf,100,MSG_WAITALL,(SA*)&cliaddr,&len[i]);
                            buf[br]=0;
                            cout<<"Message from client:"<<i+3<<buf<<"\n";
                            string str=string(buf);
                            for(int i=0;i<str.length();i++ ){
                                if(islower(buf[i])){
                                    buf[i]=toupper(buf[i]);
                                }
                            }
                            sendto(sfd[i],buf,strlen(buf),MSG_CONFIRM,(SA*)&cliaddr,len[i]);
                        }
                    }
                }
            }
        }
    }
}
