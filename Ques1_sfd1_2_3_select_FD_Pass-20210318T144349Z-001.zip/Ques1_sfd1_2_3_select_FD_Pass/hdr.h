#include<iostream>
#include<bits/stdc++.h>
#include <arpa/inet.h> 
#include <errno.h> 
#include <netinet/in.h> 
#include <signal.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <strings.h> 
#include<string.h>
#include <sys/socket.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include<sys/un.h>
#include<errno.h>
#include<stdarg.h>
#include <sys/select.h>

#define  UNIXSTR_PATH "./path14"
#define SA struct sockaddr
#define MAXLINE 1024
#define SERV_PORT 11000
#define LISTENQ 10

using namespace std;