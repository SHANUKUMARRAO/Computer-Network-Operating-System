#include "hdr.h"

ssize_t write_fd(int fd, void *ptr, size_t nbytes, int sendfd){
	struct msghdr	msg;
	struct iovec	iov[1];

	union {
	  struct cmsghdr	cm;
	  char	control[CMSG_SPACE(sizeof(int))];
	} control_un;
	struct cmsghdr	*cmptr;

	msg.msg_control = control_un.control;
	msg.msg_controllen = sizeof(control_un.control);

	cmptr = CMSG_FIRSTHDR(&msg);
	cmptr->cmsg_len = CMSG_LEN(sizeof(int));
	cmptr->cmsg_level = SOL_SOCKET;
	cmptr->cmsg_type = SCM_RIGHTS;
	*((int *) CMSG_DATA(cmptr)) = sendfd;

	msg.msg_name = NULL;
	msg.msg_namelen = 0;

	iov[0].iov_base = ptr;
	iov[0].iov_len = nbytes;
	msg.msg_iov = iov;
	msg.msg_iovlen = 1;

	return(sendmsg(fd, &msg, 0));
}

int main(int argc, char **argv){
    int n=3;
	int	sockfd, sfd[n], connfd,nsfd;
	char buff[MAXLINE];
	pid_t	childpid;
	socklen_t clilen;
	struct sockaddr_in	cliaddr,cliaddr1,cliaddr2, serv_addr;
	struct sockaddr_un saddr;

	//unix sockets ipc
	sockfd = socket(AF_LOCAL, SOCK_STREAM, 0);

	bzero(&saddr, sizeof(saddr));
	saddr.sun_family = AF_LOCAL;
	strcpy(saddr.sun_path, UNIXSTR_PATH);
	if(connect(sockfd, (SA *) &saddr, sizeof(saddr))==0) 
		printf("Connection with Servicing server successfull\n");
	
	//TCP 1
	sfd[0] = socket(AF_INET, SOCK_STREAM, 0);
	bzero(&serv_addr, sizeof(serv_addr));
	serv_addr.sin_family      = AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port        = htons(11000);
	bind(sfd[0], (SA *) &serv_addr, sizeof(serv_addr));

	listen(sfd[0], LISTENQ);

    //UDP 1
    sfd[1]=socket(AF_INET, SOCK_DGRAM, 0);
    bzero(&serv_addr, sizeof(serv_addr)); 
	serv_addr.sin_family = AF_INET; 
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY); 
	serv_addr.sin_port = htons(12000);
    bind(sfd[1], (SA*)&serv_addr, sizeof(serv_addr));

    //TCP 2
    sfd[2]=socket(AF_INET, SOCK_STREAM, 0);
    bzero(&serv_addr, sizeof(serv_addr)); 
	serv_addr.sin_family = AF_INET; 
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY); 
	serv_addr.sin_port = htons(13000);
    bind(sfd[2], (SA*)&serv_addr, sizeof(serv_addr));
    listen(sfd[2],5);
    socklen_t len[n];
    int nsfd1[n];
	char buf[1024];
	strcpy(buf,"hello");
    len[0]=sizeof(cliaddr1);//cout<<"hello11\n";
    nsfd1[0]=accept(sfd[0], (struct sockaddr*)&cliaddr1, &len[0]);
    cout<<"Client3 accepted\n";
    len[2]=sizeof(cliaddr2);//cout<<"hello12\n";
    nsfd1[2]=accept(sfd[2], (struct sockaddr*)&cliaddr2, &len[2]);
    cout<<"Client5 accepted \n";
    // cout<<"hello13\n";
    for(int i=0;i<n;i++){
        if(i!=1)write_fd(sockfd, buf, 1, nsfd1[i]);
        else if(i==1)write_fd(sockfd,buf,1,sfd[i]);
    }
    // cout<<"hello14\n";
    while(1);
}

