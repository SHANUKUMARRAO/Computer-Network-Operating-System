
	// while(1) {
    //     for(int i=0;i<n;i++){
    //         FD_SET(sfd[i],&read_fds);
    //     }
    //     int no_of_ready_sfds=select(mx_fd, &read_fds, NULL, NULL, NULL);
    //     if (no_of_ready_sfds > 0){
    //         for (int i = 0; i < n; ++i){
    //             if(i!=1){
    //                 if (FD_ISSET(sfd[i],&read_fds)){
    //                     len[i] = sizeof(cliaddr); 
    //                     if(nsfd = accept(sfd[i], (struct sockaddr*)&cliaddr, &len[i])<0){
    //                         if (errno == EINTR)
    //                             continue;	
    //                         else{
    //                             perror("accept error");
    //                         }
    //                     }
    //                     if(getpeername(nsfd, (SA *) &cliaddr, &clilen)==0) {
    //                         printf("connection from %s, port %d\n",inet_ntop(AF_INET, &cliaddr.sin_addr, buff, sizeof(buff)),ntohs(cliaddr.sin_port));
    //                     }	
    //                     // char buf1[1024];
    //                     // strcpy(buf1,"hello");
    //                     string str="hello";
    //                     write_fd(sockfd, &str, 1, nsfd);
    //                     close(nsfd);
    //                 }
    //             } 
    //             else if(i==1){
    //                 if(FD_ISSET(sfd[i],&read_fds)){
    //                     len[i]=sizeof(cliaddr);
    //                     if(getpeername(sfd[i], (SA *) &cliaddr, &clilen)==0) {
    //                         printf("connection from %s, port %d\n",inet_ntop(AF_INET, &cliaddr.sin_addr, buff, sizeof(buff)),ntohs(cliaddr.sin_port));
    //                     }
    //                     write_fd(sockfd,(SA *)&cliaddr,len[i],sfd[i]);
    //                 }
    //             }
    //         }
    //     }
    // }
		// clilen = sizeof(cliaddr);
		// if ( (connfd = accept(sfd, (SA *) &cliaddr, &clilen)) < 0) {
		// 	if (errno == EINTR)
		// 		continue;	
		// 	else{
		// 		perror("accept error");
		// 	}
		// }
		// if(getpeername(connfd, (SA *) &cliaddr, &clilen)==0) {
		// 	printf("connection from %s, port %d\n",inet_ntop(AF_INET, &cliaddr.sin_addr, buff, sizeof(buff)),ntohs(cliaddr.sin_port));
		// }	
		// char buf[1024];
		// strcpy(buf,"hello");
		// write_fd(sockfd, buf, 1, connfd);

		// close(connfd);		