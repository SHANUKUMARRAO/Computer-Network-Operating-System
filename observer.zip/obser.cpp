#include<bits/stdc++.h>
#include <stdio.h>
#include <errno.h>
#include <time.h>
#include <string.h>
#include <pthread.h>
#include <signal.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/select.h>
#include <sys/un.h>
#include <sys/shm.h>
#include <sys/socket.h>
#include <semaphore.h>
#include <poll.h>
#include <errno.h>
#include <netinet/in.h>
#include <netinet/if_ether.h>
#include <net/ethernet.h>
#include <netinet/in_systm.h>
#include <netinet/ip_icmp.h>
#include <netinet/ether.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h>
#define __USE_BSD
#define __FAVOR_BSD
#define BUFSIZE 1024
using namespace std;

//............

void print_tcp_packet(unsigned char* , int);
int sock_raw;
int tcp=0,udp=0,icmp=0,others=0,igmp=0,total=0,i,j;
struct sockaddr_in source,dest;
//...............................
void ProcessPacket(unsigned char* buffer, int size)
{
struct iphdr *iph = (struct iphdr *)buffer;
++total;
switch (iph->protocol)
{
case 1: //ICMP Protocol
++icmp;
//PrintIcmpPacket(Buffer,Size);
break;
case 2: //IGMP Protocol
++igmp;
break;
case 6: //TCP Protocol
++tcp;
print_tcp_packet(buffer , size);
break;
case 17: //UDP Protocol
++udp;
//print_udp_packet(buffer , size);
break;
default: //Some Other Protocol like ARP etc.
++others;
break;
}
cout<<"Total "<<total<<" TCP - "<<tcp<<endl;
}


//IP header.........................
void print_ip_header(unsigned char* Buffer, int Size)
{
unsigned short iphdrlen;
struct iphdr *iph = (struct iphdr *)Buffer;
iphdrlen =iph->ihl*4;
memset(&source, 0, sizeof(source));
source.sin_addr.s_addr = iph->saddr;
memset(&dest, 0, sizeof(dest));
dest.sin_addr.s_addr = iph->daddr;
cout<<"Source IP -> "<<inet_ntoa(source.sin_addr)<<endl;
cout<<"Destination IP -> "<<inet_ntoa(dest.sin_addr)<<endl;
}

//..................................
void print_tcp_packet(unsigned char* Buffer, int Size)
{
unsigned short iphdrlen;
struct iphdr *iph = (struct iphdr *)Buffer;
iphdrlen = iph->ihl*4;
struct tcphdr *tcph=(struct tcphdr *)(Buffer + iphdrlen);
print_ip_header(Buffer,Size);
cout<<"Source Port -> "<<ntohs(tcph->source)<<endl;
cout<<"Destination Port -> "<<ntohs(tcph->dest)<<endl;
cout<<endl;
}



//main code-------------------
int main()
{
int saddr_size , data_size;
struct sockaddr saddr;
struct in_addr in;
unsigned char *buffer = (unsigned char *)malloc(65536);
printf("Starting...\n");
sock_raw = socket(AF_INET , SOCK_RAW , IPPROTO_TCP);
if(sock_raw < 0)
{
perror("socket");
return 1;
}
while(1)
{
saddr_size = sizeof saddr;
data_size = recvfrom(sock_raw , buffer , 65536 , 0 , &saddr ,
(socklen_t*)&saddr_size);
if(data_size <0 )
{
printf("Recvfrom error , failed to get packets\n");
return 1;
}
ProcessPacket(buffer , data_size);
}
close(sock_raw);
printf("Finished");
return 0;
}

