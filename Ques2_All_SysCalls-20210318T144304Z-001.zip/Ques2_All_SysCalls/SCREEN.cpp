#include "hdr.h"

struct mymsg{
    long mtype;
    char mdata[50];
};

int main(){
    key_t key=ftok("./D",102);
    int msqid=msgget(key,0777|IPC_CREAT);
    mymsg mbuff;
    int x;
    while(1){
        while((x=msgrcv(msqid,&mbuff,sizeof(mbuff.mdata),0,IPC_NOWAIT))==-1){}
        cout<<"N"<<mbuff.mtype<<":"<<mbuff.mdata<<"\n";
    }

}