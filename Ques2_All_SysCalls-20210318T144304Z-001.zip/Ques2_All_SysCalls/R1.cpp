#include "hdr.h"

int main(){
    cout<<"Yeah! Reporter,Your Welcome.\nPlease Enter your name here:-";
    char buf[100];
    cin>>buf;
    if(open(buf,O_RDONLY)==-1){
            mkfifo(buf,0777|IPC_CREAT);
    }
    dup2(STDOUT_FILENO,101);
    int fd=open(buf,O_WRONLY);
    dup2(fd,STDOUT_FILENO);
    
    while(1){
        char buf1[100];
        string str1;
        cout<<"\nEnter the Headlines News:-";
        getline(cin,str1);
        write(STDOUT_FILENO,str1.c_str(),str1.length());
    }
    dup2(101,STDOUT_FILENO);
}