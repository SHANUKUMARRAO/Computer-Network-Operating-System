#include<iostream>
#include <stdio.h> 
#include <unistd.h>
#include <netdb.h> 
#include <netinet/in.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#define MAX 80 
#define PORT 11000
#define SA struct sockaddr 

using namespace std;

void func(int nsfd) { 
	while(1){ 
        char buf[MAX];
        int br=recv(nsfd,buf,100,0);
        buf[br]=0;
		cout<<"Received msg:"<<buf<<"\n";
        string str1="Server:"+string(buf);
        send(nsfd,str1.c_str(),str1.size(),0);
        if(strcmp("exit",buf)==0){
            break;
        }
         
	} 
} 

int main() 
{ 
	int sfd, nsfd;
    socklen_t len; 
	struct sockaddr_in serv_addr, cli_addr; 

	sfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sfd == -1) { 
        perror("failed");
		cout<<"socket creation failed...\n"; 
		exit(0); 
	} 
	else
		cout<<"Channel is setup for livetelecasting(socket creation)..\n"; 
	bzero(&serv_addr, sizeof(serv_addr)); 
	serv_addr.sin_family = AF_INET; 
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY); 
	serv_addr.sin_port = htons(PORT); 
	if ((bind(sfd, (SA*)&serv_addr, sizeof(serv_addr))) != 0) { 
        perror("bind failed");
		cout<<"socket bind failed...\n"; 
		exit(0); 
	} 
	else
		cout<<"Live telecating is getting ready(binded) \n"; 

	if ((listen(sfd, 5)) != 0) { 
		cout<<"Listen failed...\n"; 
		exit(0); 
	} 
	else
		cout<<"Waiting for live broadcasting(listening)\n";
	len = sizeof(cli_addr); 
	while(1){
        nsfd = accept(sfd, (SA*)&cli_addr,&len); 
        if (nsfd < 0) { 
            cout<<"server acccept failed \n";
            exit(0); 
        } 
        else
            cout<<"Live telecasting 'STARTED'...! \n";

        while(1) { 
            char buff[MAX]; 
            cout<<"Enter Your Live message : "; 
            string str1;
            getline(cin,str1);
            send(nsfd, str1.c_str(), str1.length(),0); 
            // int br=recv(nsfd, buff, 100,0);
            // buff[br]=0; 
            // cout<< buff<<"\n"; 
            if(str1=="exit"){
                break;
            } 
	    } 
        close(nsfd); 
    }
	 close(sfd);
} 
