#include "hdr.h"

struct mymsg{
    long mtype;
    char mdata[50];
};
int *shrd_var;
int *no_of_active_live_telecasts;
ssize_t write_fd(int fd, void *ptr, size_t nbytes, int sendfd){
	struct msghdr	msg;
	struct iovec	iov[1];

	union {
	  struct cmsghdr	cm;
	  char	control[CMSG_SPACE(sizeof(int))];
	} control_un;
	struct cmsghdr	*cmptr;

	msg.msg_control = control_un.control;
	msg.msg_controllen = sizeof(control_un.control);

	cmptr = CMSG_FIRSTHDR(&msg);
	cmptr->cmsg_len = CMSG_LEN(sizeof(int));
	cmptr->cmsg_level = SOL_SOCKET;
	cmptr->cmsg_type = SCM_RIGHTS;
	*((int *) CMSG_DATA(cmptr)) = sendfd;

	msg.msg_name = NULL;
	msg.msg_namelen = 0;

	iov[0].iov_base = ptr;
	iov[0].iov_len = nbytes;
	msg.msg_iov = iov;
	msg.msg_iovlen = 1;

	return(sendmsg(fd, &msg, 0));
}



int main(int argc, char **argv){
	int	sockfd, listenfd, connfd,n=3;
	char buff[MAXLINE];
	pid_t	childpid;
	socklen_t clilen;
	struct sockaddr_in	cliaddr, servaddr;
	struct sockaddr_un saddr;
    
//unix sockets ipc
	sockfd = socket(AF_LOCAL, SOCK_STREAM, 0);
	bzero(&saddr, sizeof(saddr));
	saddr.sun_family = AF_LOCAL;
	strcpy(saddr.sun_path, UNIXSTR_PATH);


////****Shared memory to swith between two newsreaders****/////
    key_t key = ftok("/E.cpp", 100);
    int shmid = shmget(key, 2*sizeof(int), 0777 | IPC_CREAT);
    shrd_var=(int *)shmat(shmid, NULL, 0777);
    *shrd_var=1;
    no_of_active_live_telecasts=shrd_var+1;
    *no_of_active_live_telecasts=0;
////////********************/////////////


////****Message Queues Decalrations*****/////

    key_t key1=ftok("./NR1",101);
    int msqid=msgget(key1,0777|IPC_CREAT);

///////////********************//////////////

//////////declarations for select system call /////////
    fd_set read_fds;
    int fds[n],mx_fd=-1;
    fds[0]=open("R1",O_RDONLY);//cout<<"hello1\n";
    fds[1]=open("R2",O_RDONLY);//cout<<"hello2\n";
    fds[2]=open("R3",O_RDONLY);//cout<<"hello3\n";
    for(int i=0;i<n;i++){
        if(fds[i]>mx_fd)
            mx_fd=fds[i];
    }
    mx_fd+=1;
    FD_ZERO(&read_fds);
//////////////////*******************//////////////////////


    vector<bool> status(n,false);
    
	while(1){
        for(int i=0;i<n;i++)
            FD_SET(fds[i],&read_fds);

        int no_of_ready_fds=select(mx_fd,&read_fds,NULL,NULL,NULL);
        if(no_of_ready_fds>0){
            for(int i=0;i<n;i++){
                if(FD_ISSET(fds[i],&read_fds) && status[i]==false){
                    char buf[1024];
                    int br=read(fds[i],buf,1024);
                    buf[br]=0;
                    
                    if(strcmp(buf,"/d")==0){                              
                        if(connect(sockfd, (SA *) &saddr, sizeof(saddr))==0) 
                            printf("Connection with Servicing server successfull\n");
                        char buf[1024];
                        strcpy(buf,"hello");
                        status[i]=true;
                        write_fd(sockfd, buf, 1, fds[i]);
                        // close(fds[i]);	                   
                    }
                    else{
                        mymsg mbuff;
                        while(*shrd_var==3);
                        mbuff.mtype=*shrd_var;
                        strcpy(mbuff.mdata,buf);
                        msgsnd(msqid,&mbuff,sizeof(mbuff.mdata),IPC_NOWAIT);
                        if(*shrd_var==1)
                            *shrd_var=2;
                        else if(*shrd_var==2)
                            *shrd_var=1;
                        if((buf[0]-48)>=0 && (buf[0]-48)<10){//cout<<"port="<<buf<<"\n";
                            *no_of_active_live_telecasts += 1;
                            int c=fork();
                            if(c>0){
                            }
                            else{
                                key_t key2 = ftok("/E.cpp", 100);
                                int shmid = shmget(key2, 2*sizeof(int), 0777 | IPC_CREAT);
                                int *x;
                                x=(int *)shmat(shmid, NULL, 0777);
                                int prev=x[0];
                                x[0]=3;
                                mymsg mbuff1;
                                while((msgrcv(msqid,&mbuff1,sizeof(mbuff1.mdata),3,IPC_NOWAIT)==-1)){}
                                    x[0]=prev;
                                    cout<<"A LiveTelecasting is Completed\n";
                                    cout<<"So far "<<x[1]<<" Livetelecasts have been completed\n";
                                
                            }
                        }
                    }
                }
            }
        }
	}
}

