#include "hdr.h"

struct mymsg{
    long mtype;
    char mdata[50];
};

int msqid2;
void func(int port){
    int sfd, connfd; 
	struct sockaddr_in servaddr, cli; 

	sfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sfd == -1) { 
		cout<<"socket creation failed...\n"; 
		exit(0); 
	} 
	else
		cout<<"Livetelecast socket is successfully created\n"; 
	bzero(&servaddr, sizeof(servaddr)); 
	servaddr.sin_family = AF_INET; 
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1"); 
	servaddr.sin_port = htons(port); 

	if (connect(sfd, (SA*)&servaddr, sizeof(servaddr)) != 0) { 
		cout<<"connection with the server failed...\n"; 
		exit(0); 
	} 
	else
		cout<<"Livetelecast is susccefully initiated\n"; 
    while(1){ 
        char buf[1024];
        int br=recv(sfd,buf,100,0);
        buf[br]=0;
        mymsg mbuff1;
        mbuff1.mtype=21;
        strcpy(mbuff1.mdata,buf);
        msgsnd(msqid2,&mbuff1,sizeof(mbuff1.mdata),IPC_NOWAIT);
        if(strcmp("exit",buf)==0){
            break;
        }
         
	} 
    
}


int main(){
    key_t key=ftok("./D",102);
    msqid2=msgget(key,0777|IPC_CREAT);
    key_t key1=ftok("./NR1",101);
    int msqid=msgget(key1,0777|IPC_CREAT);
    while(1){
    mymsg mbuff;
    while(msgrcv(msqid,&mbuff,sizeof(mbuff.mdata),2,IPC_NOWAIT)==-1){}
        // cout<<"nr2:msg:"<<mbuff.mdata<<"\n";
        char ch=mbuff.mdata[0];
        if((ch-48)>=0 && (ch-48)<10){
            int port=atoi(mbuff.mdata);
            func(port);
            mbuff.mtype=3;
            msgsnd(msqid,&mbuff,sizeof(mbuff.mdata),IPC_NOWAIT);
        }
        else{
            mymsg mbuff1;
            mbuff1.mtype=2;
            strcpy(mbuff1.mdata,mbuff.mdata);
            msgsnd(msqid2,&mbuff1,sizeof(mbuff1.mdata),IPC_NOWAIT);
        }

    }
}