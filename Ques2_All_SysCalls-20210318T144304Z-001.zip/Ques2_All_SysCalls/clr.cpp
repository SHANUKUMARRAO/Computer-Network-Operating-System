#include<sys/msg.h>
#include<stdio.h>
#include<iostream>
#include<sys/ipc.h>
#include<string.h>
#include <sys/types.h>
#include <unistd.h>
#include <fstream>

using namespace std;

ofstream fout;
int gmsqid,msqid1,msqid2;

struct mymsg{
    long mtype;
    char mdata[50];
};

int main(){

    key_t key=ftok("./D",102);
    gmsqid=msgget(key,0777|IPC_CREAT);

    key_t key2=ftok("./NR1",101);
    msqid1=msgget(key2,0777|IPC_CREAT);

    msgctl(gmsqid,IPC_RMID,NULL);
    msgctl(msqid1,IPC_RMID,NULL);
    return 0;
}